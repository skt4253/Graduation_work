import numpy as np
import pandas as pd

input_file = "posture.csv"
df_train = pd.read_csv(input_file)

data_train = df_train.to_numpy()

sensor_input = df_train[['sensor1','sensor2','sensor3','sensor4','sensor5','sensor6','sensor7','sensor8','sensor9','sensor10','sensor11','sensor12','sensor13','sensor14','sensor15','sensor16','sensor17','sensor18','sensor19','sensor20','sensor21','sensor22','sensor23','sensor24','sensor25','sensor26','sensor27','sensor28','sensor29','sensor30','sensor31']].to_numpy()
sensor_input[:31]
sensor_target = df_train['posture'].to_numpy()

from sklearn.model_selection import train_test_split
train_input, test_input, train_target, test_target = train_test_split(sensor_input, sensor_target, random_state=42)

from sklearn.preprocessing import StandardScaler
ss = StandardScaler()
ss.fit(train_input)
train_scaled = ss.transform(train_input)
test_scaled = ss.transform(test_input)

from sklearn.neighbors import KNeighborsClassifier
kn = KNeighborsClassifier(n_neighbors =3)
kn.fit(train_scaled, train_target)

import pickle
pickle.dump(kn, open('posture.pkl', 'wb'))