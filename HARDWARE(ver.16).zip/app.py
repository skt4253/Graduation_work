from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import pymysql

model = pickle.load(open('posture.pkl', 'rb'))

app = Flask(__name__)

input_file = "posture.csv"
df_train = pd.read_csv(input_file)
sensor_input = df_train[['sensor1','sensor2','sensor3','sensor4','sensor5','sensor6','sensor7','sensor8','sensor9','sensor10','sensor11','sensor12','sensor13','sensor14','sensor15','sensor16','sensor17','sensor18','sensor19','sensor20','sensor21','sensor22','sensor23','sensor24','sensor25','sensor26','sensor27','sensor28','sensor29','sensor30','sensor31']].to_numpy()
sensor_input[:31]
sensor_target = df_train['posture'].to_numpy()
train_input, test_input, train_target, test_target = train_test_split(sensor_input, sensor_target, random_state=42)


@app.route('/')
def man():
    
    db = pymysql.connect(host="localhost",
        user="root", password="",
        charset="utf8")

    cursor = db.cursor(pymysql.cursors.DictCursor)
    cursor.execute('USE eu;') 

    cursor.execute('SELECT * FROM eu;')
    value = cursor.fetchall() 

    
    db.commit()
    db.close()

    data1 = value[0]["sensor1"]
    data2 = value[0]["sensor2"]
    data3 = value[0]["sensor3"]
    data4 = value[0]["sensor4"]
    data5 = value[0]["sensor5"]
    data6 = value[0]["sensor6"]
    data7 = value[0]["sensor7"]
    data8 = value[0]["sensor8"]
    data9 = value[0]["sensor9"]
    data10 = value[0]["sensor10"]
    data11 = value[0]["sensor11"]
    data12 = value[0]["sensor12"]
    data13 = value[0]["sensor13"]
    data14 = value[0]["sensor14"]
    data15 = value[0]["sensor15"]
    data16 = value[0]["sensor16"]
    data17 = value[0]["sensor17"]
    data18 = value[0]["sensor18"]
    data19 = value[0]["sensor19"]
    data20 = value[0]["sensor20"]
    data21 = value[0]["sensor21"]
    data22 = value[0]["sensor22"]
    data23 = value[0]["sensor23"]
    data24 = value[0]["sensor24"]
    data25 = value[0]["sensor25"]
    data26 = value[0]["sensor26"]
    data27 = value[0]["sensor27"]
    data28 = value[0]["sensor28"]
    data29 = value[0]["sensor29"]
    data30 = value[0]["sensor30"]
    data31 = value[0]["sensor31"]
      
    arr = np.array([[data1, data2, data3, data4,data5, data6, data7, data8, data9, data10,data11, data12, data13, data14,data15, data16, data17, data18, data19, data20,data21, data22, data23, data24,data25, data26, data27, data28, data29, data30,data31]])
    ss = StandardScaler()
    ss.fit(train_input)
    stdarr = ss.transform(arr)

    pred = model.predict(stdarr)
    return render_template('after.html', data=pred)
  
if __name__ == "__main__":
    app.run(debug=True)