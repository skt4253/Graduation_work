create table weeks (
    num int not null auto_increment,
    id char(16) not null,
    monday int,
    monday_eu int,
    tuesday int,
    tuesday_eu int,
    wednesday int,
    wednesday_eu int,
    thursday int,
    thursday_eu int,
    friday int,
    friday_eu int,
    saturday int,
    saturday_eu int,
    sunday int,
    sunday_eu int,
    primary key(num)
);
