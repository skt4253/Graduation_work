create table dayCount (
    num int not null auto_increment,
    id char(16) not null,
    timer  int,
    eu int,
    primary key(num)
);
