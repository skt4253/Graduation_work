from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import serial
from flask import Response

model = pickle.load(open('posture.pkl', 'rb'))

app = Flask(__name__)

input_file = "posture1.csv"
df_train = pd.read_csv(input_file)

sensor_input = df_train[['sensor1','sensor2','sensor3','sensor4','sensor5','sensor6','sensor7','sensor8','sensor9','sensor10','sensor11','sensor12','sensor13','sensor14','sensor15','sensor16','sensor17','sensor18','sensor19','sensor20','sensor21','sensor22','sensor23','sensor24','sensor25','sensor26','sensor27','sensor28','sensor29','sensor30','sensor31']].to_numpy()
sensor_input[:31]
sensor_target = df_train['posture'].to_numpy()


train_input, test_input, train_target, test_target = train_test_split(sensor_input, sensor_target, random_state=42)

PORT = 'COM10' 
BaudRate = 9600 

@app.route('/')
def man():
    ARD= serial.Serial(PORT,BaudRate)

    while (True): 
        if ARD.readable():
            res = ARD.readline()
            a = res.decode()[:len(res)-1]
            b = a.split('/')

        data1 = b[0]
        data2 = b[1]
        data3 = b[2]
        data4 = b[3]
        data5 = b[4]
        data6 = b[5]
        data7 = b[6]
        data8 = b[7]
        data9 = b[8]
        data10 = b[9]
        data11 = b[10]
        data12 = b[11]
        data13 = b[12]
        data14 = b[13]
        data15 = b[14]
        data16 = b[15]
        data17 = b[16]
        data18 = b[17]
        data19 = b[18]
        data20 = b[19]
        data21 = b[20]
        data22 = b[21]
        data23 = b[22]
        data24 = b[23]
        data25 = b[24]
        data26 = b[25]
        data27 = b[26]
        data28 = b[27]
        data29 = b[28]
        data30 = b[29]
        data31 = b[30]
        
        arr = np.array([[data1, data2, data3, data4,data5, data6, data7, data8, data9, data10,data11, data12, data13, data14,data15, data16, data17, data18, data19, data20,data21, data22, data23, data24,data25, data26, data27, data28, data29, data30,data31]])
        ss = StandardScaler()
        ss.fit(train_input)
        stdarr = ss.transform(arr)

        pred = model.predict(stdarr)
        return render_template('after.html', data=pred)
  
if __name__ == "__main__":
    app.run(debug=True)