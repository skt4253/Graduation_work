<?php
     $host = 'localhost'; //localhost
     $user = 'root'; //ID
     $pw = ''; //비밀번호
     $dbName = 'eu'; //DB이름
     $mysqli = new mysqli($host, $user, $pw, $dbName);
     
     //테이블 LIMIT해서 행 1줄 가져오게 함
     $sql = "SELECT posture FROM posture LIMIT 1";
     $result = mysqli_query($mysqli, $sql);
     if (mysqli_num_rows($result) > 0) {
     while($row = mysqli_fetch_assoc($result)) {
         $posture = $row['posture'];
         
         //출력
         // echo $posture."<br>";
        if ($posture == "['right']"){
             echo "하체가 오른쪽 기울어졌습니다.";
         }else if($posture == "['left']"){
             echo "하체가 왼쪽 기울어졌습니다.";
         }else if($posture == "['front']"){
             echo "하체가 앞으로 기울어졌습니다.";
         }else if($posture == "['back']"){
             echo "하체가 뒤로 기울어졌습니다.";
         }else if($posture == "['empty']"){
             echo "자리가 비었습니다.";
         }else if($posture == "['correct']"){
             echo "자세가 바릅니다.";
         }
    }
    }else{
         echo "테이블에 데이터가 없습니다.";
    }
    mysqli_close($mysqli); // 디비 접속 닫기
?>
