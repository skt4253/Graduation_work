create table groups (
    num int not null auto_increment,
    id char(16) not null,
    group  char(32),
    primary key(num)
);
