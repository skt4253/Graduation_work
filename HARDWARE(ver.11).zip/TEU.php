<?php 
header("Content-Type: text/html;charset=UTF-8");
// header("Content-Type: apllication/json;charset=UTF-8");

$host = 'localhost'; //localhost
$user = 'root'; //ID
$pw = ''; //비밀번호
$dbName = 'eu'; //DB이름
$mysqli = new mysqli($host, $user, $pw, $dbName);

    if($mysqli){
        echo "MySQL successfully connected!<br/>";
        
        $all = $_GET['sensor1']; //아두이노에서 받은 값(0/0/0/0/0/0/0/0 이런식의 압력센서 31개의 값)을 $all에 저장

        // $all에 있는 문자열을 "/"를 기준으로 나눠서 senser별로 저장 
        list($sensor1, $sensor2, $sensor3, $sensor4, $sensor5, $sensor6, $sensor7, $sensor8, $sensor9, $sensor10, $sensor11, $sensor12, $sensor13, $sensor14, $sensor15, $sensor16, $sensor17, $sensor18, $sensor19, $sensor20, $sensor21, $sensor22, $sensor23, $sensor24, $sensor25, $sensor26, $sensor27, $sensor28, $sensor29, $sensor30, $sensor31) = explode("/", $all);


        //테이블에 입력
        $query = "INSERT INTO eu (sensor1, sensor2, sensor3, sensor4, sensor5, sensor6, sensor7, sensor8, sensor9, sensor10, sensor11, sensor12, sensor13, sensor14, sensor15, sensor16, sensor17, sensor18, sensor19, sensor20, sensor21, sensor22, sensor23, sensor24, sensor25, sensor26, sensor27, sensor28, sensor29, sensor30, sensor31) VALUES ('$sensor1','$sensor2','$sensor3','$sensor4','$sensor5','$sensor6','$sensor7','$sensor8','$sensor9','$sensor10', '$sensor11','$sensor12','$sensor13','$sensor14','$sensor15','$sensor16','$sensor17','$sensor18','$sensor19','$sensor20', '$sensor21','$sensor22','$sensor23','$sensor24','$sensor25','$sensor26','$sensor27','$sensor28','$sensor29','$sensor30', '$sensor31')";
        mysqli_query($mysqli,$query);
        
        echo "</br>success!!";
    }

    else{
        echo "MySQL could not be connected";
    }
        
mysqli_close($mysqli);
?>
