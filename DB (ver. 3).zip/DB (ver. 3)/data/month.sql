create table months (
    num int not null auto_increment,
    id char(16) not null,
    thisMonth  int,
    1monthAgo int,
    2monthAgo int,
    3monthAgo int,
    primary key(num)
);
