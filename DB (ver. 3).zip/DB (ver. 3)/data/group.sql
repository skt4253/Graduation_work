create table groups (
    num int not null auto_increment,
    id char(16) not null,
    group1  char(16),
    group2  char(16),
    group3  char(16),
    primary key(num)
);
