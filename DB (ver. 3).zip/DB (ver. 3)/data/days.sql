create table dayCount (
    num int not null auto_increment,
    id char(16) not null,
    timer  int,
    primary key(num)
);
