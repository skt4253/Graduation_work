create table weeks (
    num int not null auto_increment,
    id char(16) not null,
    monday int,
    tuesday int,
    wednesday int,
    thursday int,
    friday int,
    saturday int,
    sunday int,
    primary key(num)
);
