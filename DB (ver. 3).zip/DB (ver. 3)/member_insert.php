<?php   // 회원 가입 (insert) 기능
    $id  = $_POST["id"];
    $pass = $_POST["pass"];
    $name = $_POST["name"];
    $regist_day = date("Y-m-d (H:i)");
              
    $con = mysqli_connect("localhost", "root", "", "user"); // mysqli_connect("localhost", "아이디", "비밀번호", "DB");
	$sql = "insert into members(id, pass, name, regist_day)"; // "레코드에 데이터 create"하는 명령어
	$sql .= "values('$id', '$pass', '$name', '$regist_day')"; // 실제 데이터 입력
    mysqli_query($con, $sql); // 데이터베이스에 저장
    $sql = "insert into dayCount(id)"; // 일 데이터 저장 DB
	$sql .= "values('$id')";
    mysqli_query($con, $sql);
    $sql = "insert into weeks(id)"; // 주 데이터 저장 DB
	$sql .= "values('$id')";
    mysqli_query($con, $sql);
    $sql = "insert into months(id)"; // 월 데이터 저장 DB
	$sql .= "values('$id')";
    mysqli_query($con, $sql);
    $sql = "insert into groups(id)"; // 그룹 지정 DB
	$sql .= "values('$id')";
	mysqli_query($con, $sql);
    mysqli_close($con); // 데이터베이스 닫기

    // 데이터베이스 구조
    // 관계형 데이터베이스: DB -> table -> record, field
    
    echo "
	      <script>
            alert(\"회원 가입이 완료됐습니다.\");
	        location.href = 'member_form.php';
	      </script>
	  ";
?>