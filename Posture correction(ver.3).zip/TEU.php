<?php 
header("Content-Type: text/html;charset=UTF-8");

$host = 'localhost'; //localhost
$user = 'root'; //ID
$pw = ''; //비밀번호
$dbName = 'eu'; //DB이름
$mysqli = new mysqli($host, $user, $pw, $dbName);

    if($mysqli){
        echo "MySQL successfully connected!<br/>";
        
        $sensor1 = $_GET['sensor1'];
        $sensor2 = $_GET['sensor2'];
        $sensor3 = $_GET['sensor3'];
        $sensor4 = $_GET['sensor4'];
        $sensor5 = $_GET['sensor5'];
        $sensor6 = $_GET['sensor6'];
        $sensor7 = $_GET['sensor7'];
        $sensor8 = $_GET['sensor8'];
        $sensor9 = $_GET['sensor9'];
        $sensor10 = $_GET['sensor10'];
        $sensor11 = $_GET['sensor11'];
        $sensor12 = $_GET['sensor12'];
        $sensor13 = $_GET['sensor13'];
        $sensor14 = $_GET['sensor14'];
        $sensor15 = $_GET['sensor15'];
        $sensor16 = $_GET['sensor16'];
        $sensor17 = $_GET['sensor17'];
        $sensor18 = $_GET['sensor18'];
        $sensor19 = $_GET['sensor19'];
        $sensor20 = $_GET['sensor20'];
        $sensor21 = $_GET['sensor21'];
        $sensor22 = $_GET['sensor22'];
        $sensor23 = $_GET['sensor23'];
        $sensor24 = $_GET['sensor24'];
        $sensor25 = $_GET['sensor25'];
        $sensor26 = $_GET['sensor26'];
        $sensor27 = $_GET['sensor27'];
        $sensor28 = $_GET['sensor28'];
        $sensor29 = $_GET['sensor29'];
        $sensor30 = $_GET['sensor30'];
        $sensor31 = $_GET['sensor31'];
        
        //테이블에 입력
        $query = "INSERT INTO eu (sensor1, sensor2, sensor3, sensor4, sensor5, sensor6, sensor7, sensor8, sensor9, sensor10, sensor11, sensor12, sensor13, sensor14, sensor15, sensor16, sensor17, sensor18, sensor19, sensor20, sensor21, sensor22, sensor23, sensor24, sensor25, sensor26, sensor27, sensor28, sensor29, sensor30, sensor31) VALUES ('$sensor1','$sensor2','$sensor3','$sensor4','$sensor5','$sensor6','$sensor7','$sensor8','$sensor9','$sensor10', '$sensor11','$sensor12','$sensor13','$sensor14','$sensor15','$sensor16','$sensor17','$sensor18','$sensor19','$sensor20', '$sensor21','$sensor22','$sensor23','$sensor24','$sensor25','$sensor26','$sensor27','$sensor28','$sensor29','$sensor30', '$sensor31')";
        mysqli_query($mysqli,$query);
        
        echo "</br>success!!";
    }

    else{
        echo "MySQL could not be connected";
    }
        
mysqli_close($mysqli);
?>
