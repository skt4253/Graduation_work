<?php // 회원 탈퇴 기능
    $id = $_GET["id"];
    $pass = $_GET["pass"];
    $name = $_GET["name"];
          
    $con = mysqli_connect("localhost", "root", "", "user");
    $sql = "delete from members where id= '$id'";
    mysqli_query($con, $sql);
    $sql = "delete from daycount where id= '$id'";
    mysqli_query($con, $sql);
    $sql = "delete from months where id= '$id'";
    mysqli_query($con, $sql);
    $sql = "delete from weeks where id= '$id'";
    mysqli_query($con, $sql);
    $sql = "delete from groups where id= '$id'";
    mysqli_query($con, $sql);

    mysqli_close($con);
    echo "
        <script>
            alert(\"회원 탈퇴가 완료됐습니다.\");
        </script>
    ";
    echo "
	      <script>
	        location.href = 'login_form.php';
	      </script>
	  ";
?>

   
