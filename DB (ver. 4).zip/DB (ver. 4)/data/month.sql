create table months (
    num int not null auto_increment,
    id char(16) not null,
    thisMonth  int,
    this_eu int,
    1monthAgo int,
    1_eu int,
    2monthAgo int,
    2_eu int,
    3monthAgo int,
    3_eu int,
    primary key(num)
);
