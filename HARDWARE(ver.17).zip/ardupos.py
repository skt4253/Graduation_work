import serial 
import pymysql
import time

# Set a PORT Number & baud rate 
PORT = 'COM10'  #아두이노 PORT번호
BaudRate = 9600 

ARD= serial.Serial(PORT,BaudRate) 

while (True): 
    if ARD.readable():
        res = ARD.readline()
        a = res.decode()[:len(res)-1]
        b = a.split(',')
    s1 = b[0]
    s2 = b[1]
    s3 = b[2]
    s4 = b[3]
    s5 = b[4]
    s6 = b[5]
    s7 = b[6]
    s8 = b[7]
    s9 = b[8]
    s10 = b[9]
    s11 = b[10]
    s12 = b[11]
    s13 = b[12]
    s14 = b[13]
    s15 = b[14]
    s16 = b[15]
    s17 = b[16]
    s18 = b[17]
    s19 = b[18]
    s20 = b[19]
    s21 = b[20]
    s22 = b[21]
    s23 = b[22]
    s24 = b[23]
    s25 = b[24]
    s26 = b[25]
    s27 = b[26]
    s28 = b[27]
    s29 = b[28]
    s30 = b[29]
    s31 = b[30]

    db = pymysql.connect(host="localhost",
        user="root", password="",
        charset="utf8")
        
    cursor = db.cursor(pymysql.cursors.DictCursor)
    cursor.execute('USE eu;')   

    cursor.execute('UPDATE eu SET sensor1=%s, sensor2=%s,sensor3=%s,sensor4=%s,sensor5=%s,sensor6=%s,sensor7=%s,sensor8=%s,sensor9=%s,sensor10=%s,sensor11=%s, sensor12=%s,sensor13=%s,sensor14=%s,sensor15=%s,sensor16=%s,sensor17=%s,sensor18=%s,sensor19=%s,sensor20=%s,sensor21=%s, sensor22=%s,sensor23=%s,sensor24=%s,sensor25=%s,sensor26=%s,sensor27=%s,sensor28=%s,sensor29=%s,sensor30=%s,sensor31=%s'
                    ,(s1, s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21, s22,s23,s24,s25,s26,s27,s28,s29,s30,s31))
    
    
    db.commit()
    db.close()

    db = pymysql.connect(host="localhost",
        user="root", password="",
        charset="utf8")

    cursor = db.cursor(pymysql.cursors.DictCursor)
    cursor.execute('USE eu;') 

    cursor.execute('SELECT * FROM posture;')
    value = cursor.fetchall() 

    
    db.commit()
    db.close()

    posture = value[0]["posture"]
    posture = str(posture)
    posture = posture.strip("[""]""'")

    print(posture)

    vala = '0'
    valb = '1'

    if posture == 'front':
        valb = valb.encode('utf-8')
        ARD.write(valb)
        # time.sleep(0.5)
    
    elif posture == 'back':
        valb = valb.encode('utf-8')
        ARD.write(valb)
        # time.sleep(0.5)

    elif posture == 'left':
        valb = valb.encode('utf-8')
        ARD.write(valb)
        # time.sleep(0.5)

    elif posture == 'right':
        valb = valb.encode('utf-8')
        ARD.write(valb)
        # time.sleep(0.5)

    elif posture == 'empty':
        vala = vala.encode('utf-8')
        ARD.write(vala)
        # time.sleep(0.5)

    elif posture == 'correct':
        vala = vala.encode('utf-8')
        ARD.write(vala)
        # time.sleep(0.5)
