-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- 생성 시간: 22-05-16 22:07
-- 서버 버전: 10.4.22-MariaDB
-- PHP 버전: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `eu`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `eu`
--

CREATE TABLE `eu` (
  `sensor1` int(3) NOT NULL,
  `sensor2` int(3) NOT NULL,
  `sensor3` int(3) NOT NULL,
  `sensor4` int(3) NOT NULL,
  `sensor5` int(3) NOT NULL,
  `sensor6` int(3) NOT NULL,
  `sensor7` int(3) NOT NULL,
  `sensor8` int(3) NOT NULL,
  `sensor9` int(3) NOT NULL,
  `sensor10` int(3) NOT NULL,
  `sensor11` int(3) NOT NULL,
  `sensor12` int(3) NOT NULL,
  `sensor13` int(3) NOT NULL,
  `sensor14` int(3) NOT NULL,
  `sensor15` int(3) NOT NULL,
  `sensor16` int(3) NOT NULL,
  `sensor17` int(3) NOT NULL,
  `sensor18` int(3) NOT NULL,
  `sensor19` int(3) NOT NULL,
  `sensor20` int(3) NOT NULL,
  `sensor21` int(3) NOT NULL,
  `sensor22` int(3) NOT NULL,
  `sensor23` int(3) NOT NULL,
  `sensor24` int(3) NOT NULL,
  `sensor25` int(3) NOT NULL,
  `sensor26` int(3) NOT NULL,
  `sensor27` int(3) NOT NULL,
  `sensor28` int(3) NOT NULL,
  `sensor29` int(3) NOT NULL,
  `sensor30` int(3) NOT NULL,
  `sensor31` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 테이블의 덤프 데이터 `eu`
--

INSERT INTO `eu` (`sensor1`, `sensor2`, `sensor3`, `sensor4`, `sensor5`, `sensor6`, `sensor7`, `sensor8`, `sensor9`, `sensor10`, `sensor11`, `sensor12`, `sensor13`, `sensor14`, `sensor15`, `sensor16`, `sensor17`, `sensor18`, `sensor19`, `sensor20`, `sensor21`, `sensor22`, `sensor23`, `sensor24`, `sensor25`, `sensor26`, `sensor27`, `sensor28`, `sensor29`, `sensor30`, `sensor31`) VALUES
(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
