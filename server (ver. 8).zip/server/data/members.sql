create table members (
    id char(20) primary key,
    pass char(20) not null,
    passcheck char(20) not null,
    name char(10) not null,
    email char(80),
    birth datetime
);
