<?php // 로그아웃 기능
  session_start();
  unset($_SESSION["userid"]);
  unset($_SESSION["username"]);
?>
