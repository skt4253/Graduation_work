<?php
    $id   = $_POST["id"];
    $pass = $_POST["pass"];
    $name = $_POST["name"];
    $regist_day = date("Y-m-d (H:i)");
              
    $con = mysqli_connect("localhost", "users", "skt4253", "members"); // mysqli_connect("localhost", "데이터베이스", "비밀번호", "테이블");

	$sql = "insert into users(id, pass, name, regist_day)"; // "레코드에 데이터 create"하는 명령어
	$sql .= "values('$id', '$pass', '$name', '$regist_day')"; // 실제 데이터 입력

	mysqli_query($con, $sql); // 데이터베이스에 저장
    mysqli_close($con); // 데이터베이스 닫기

    // 데이터베이스 구조
    // 관계형 데이터베이스: DB -> table -> record, field
?>