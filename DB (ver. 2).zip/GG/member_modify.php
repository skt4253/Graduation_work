<?php   // 회원 정보 변경 기능
    $id = $_GET["id"];
    $pass = $_POST["pass"];
    $name = $_POST["name"];
          
    $con = mysqli_connect("localhost", "users", "", "members");
    $sql = "update members set pass='$pass', name='$name'";
    $sql .= " where id='$id'";
    mysqli_query($con, $sql);

    mysqli_close($con);
?>